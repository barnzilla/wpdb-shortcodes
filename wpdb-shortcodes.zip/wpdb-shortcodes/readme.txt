=== CSTA databases ===
Contributors: barnzilla2016
Donate link: http://www.barnzilla.ca
Tags: custom
Requires at least: 4.0
Tested up to: 6.0.2
Stable tag: trunk
Requires PHP: 7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A plugin that enables administrators to interact with their database via shortcodes.

== Description ==

A plugin that enables administrators to interact with their database via shortcodes.

== Installation ==

Manual installation:

1. Upload the plugin files to the `/wp-content/plugins/wpdb-shortcodes` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress. 
3. Insert any of the available shortcodes in a page.

== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==
=0.1=
* Initial release.